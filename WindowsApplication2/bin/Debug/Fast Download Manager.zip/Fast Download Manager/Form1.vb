﻿Imports System.Net

Public Class Form1
    Public WithEvents download As WebClient

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
        download = New WebClient
        download.DownloadFileAsync(New Uri(TextBox1.Text), TextBox2.Text)
        Catch ex As Exception
            MsgBox("Error: " & ex.Message)
        End Try
    End Sub
    Private Sub download_DownloadProgressChanged(ByVal sender As System.Object, ByVal e As System.Net.DownloadProgressChangedEventArgs) Handles download.DownloadProgressChanged
        Try
            Label1.Text = "Downloaded: " & e.BytesReceived / 1000000 & "MB /" & e.TotalBytesToReceive / 1000000 & "MB"
            Label2.Text = "Progress: " & ProgressBar1.Value & "%"
            ProgressBar1.Value = e.ProgressPercentage
        Catch ex As Exception
        End Try
    End Sub

    Private Sub download_DownloadFileCompleted(sender As Object, e As System.ComponentModel.AsyncCompletedEventArgs) Handles download.DownloadFileCompleted

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        
        ofd.ShowDialog()
        TextBox2.Text = ofd.FileName
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
