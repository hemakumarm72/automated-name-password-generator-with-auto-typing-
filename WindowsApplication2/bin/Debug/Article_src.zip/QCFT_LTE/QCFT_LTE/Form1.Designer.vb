﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
   

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.phonemodel = New System.Windows.Forms.TextBox()
        Me.swmodel = New System.Windows.Forms.TextBox()
        Me.checkpPhoneModel = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.spccode = New System.Windows.Forms.TextBox()
        Me.download = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.checkBox_BackupQCN = New System.Windows.Forms.CheckBox()
        Me.checkBox_RandomSPC = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnprogrammerpath = New System.Windows.Forms.Button()
        Me.textboxprogrammer = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.infowindow = New System.Windows.Forms.RichTextBox()
        Me.checkBoxauto = New System.Windows.Forms.CheckBox()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.spccode)
        Me.GroupBox1.Controls.Add(Me.download)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.checkBox_BackupQCN)
        Me.GroupBox1.Controls.Add(Me.checkBox_RandomSPC)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.btnprogrammerpath)
        Me.GroupBox1.Controls.Add(Me.textboxprogrammer)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(2, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(979, 242)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.phonemodel)
        Me.GroupBox2.Controls.Add(Me.swmodel)
        Me.GroupBox2.Controls.Add(Me.checkpPhoneModel)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(221, 114)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(358, 107)
        Me.GroupBox2.TabIndex = 30
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Device"
        Me.GroupBox2.UseCompatibleTextRendering = True
        '
        'phonemodel
        '
        Me.phonemodel.BackColor = System.Drawing.Color.WhiteSmoke
        Me.phonemodel.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.phonemodel.Location = New System.Drawing.Point(203, 77)
        Me.phonemodel.Multiline = True
        Me.phonemodel.Name = "phonemodel"
        Me.phonemodel.ReadOnly = True
        Me.phonemodel.Size = New System.Drawing.Size(149, 25)
        Me.phonemodel.TabIndex = 12
        '
        'swmodel
        '
        Me.swmodel.BackColor = System.Drawing.Color.WhiteSmoke
        Me.swmodel.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.swmodel.Location = New System.Drawing.Point(203, 46)
        Me.swmodel.Multiline = True
        Me.swmodel.Name = "swmodel"
        Me.swmodel.ReadOnly = True
        Me.swmodel.Size = New System.Drawing.Size(149, 27)
        Me.swmodel.TabIndex = 11
        '
        'checkpPhoneModel
        '
        Me.checkpPhoneModel.AutoCheck = False
        Me.checkpPhoneModel.AutoSize = True
        Me.checkpPhoneModel.Checked = True
        Me.checkpPhoneModel.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkpPhoneModel.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkpPhoneModel.ForeColor = System.Drawing.Color.DimGray
        Me.checkpPhoneModel.Location = New System.Drawing.Point(0, 19)
        Me.checkpPhoneModel.Name = "checkpPhoneModel"
        Me.checkpPhoneModel.Size = New System.Drawing.Size(174, 24)
        Me.checkpPhoneModel.TabIndex = 5
        Me.checkpPhoneModel.Text = "Phone Model Check"
        Me.checkpPhoneModel.ThreeState = True
        Me.checkpPhoneModel.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft PhagsPa", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(-2, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(177, 18)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Phone Preview S/W Model :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft PhagsPa", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(-2, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(181, 18)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Download  Software Model :"
        '
        'spccode
        '
        Me.spccode.Location = New System.Drawing.Point(656, 184)
        Me.spccode.Multiline = True
        Me.spccode.Name = "spccode"
        Me.spccode.Size = New System.Drawing.Size(146, 27)
        Me.spccode.TabIndex = 23
        Me.spccode.Visible = False
        '
        'download
        '
        Me.download.Font = New System.Drawing.Font("Microsoft YaHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.download.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.download.Location = New System.Drawing.Point(840, 174)
        Me.download.Name = "download"
        Me.download.Size = New System.Drawing.Size(135, 56)
        Me.download.TabIndex = 22
        Me.download.Text = "Flash Start"
        Me.download.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(695, 156)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 13)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "SPC Code"
        Me.Label8.Visible = False
        '
        'checkBox_BackupQCN
        '
        Me.checkBox_BackupQCN.AutoSize = True
        Me.checkBox_BackupQCN.Location = New System.Drawing.Point(648, 124)
        Me.checkBox_BackupQCN.Name = "checkBox_BackupQCN"
        Me.checkBox_BackupQCN.Size = New System.Drawing.Size(154, 17)
        Me.checkBox_BackupQCN.TabIndex = 27
        Me.checkBox_BackupQCN.Text = "Auto Backup Restore QCN"
        Me.checkBox_BackupQCN.UseVisualStyleBackColor = True
        Me.checkBox_BackupQCN.Visible = False
        '
        'checkBox_RandomSPC
        '
        Me.checkBox_RandomSPC.AutoSize = True
        Me.checkBox_RandomSPC.Location = New System.Drawing.Point(812, 124)
        Me.checkBox_RandomSPC.Name = "checkBox_RandomSPC"
        Me.checkBox_RandomSPC.Size = New System.Drawing.Size(118, 17)
        Me.checkBox_RandomSPC.TabIndex = 28
        Me.checkBox_RandomSPC.Text = "Random SPC Code"
        Me.checkBox_RandomSPC.UseVisualStyleBackColor = True
        Me.checkBox_RandomSPC.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft YaHei", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(446, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(172, 25)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "No Port Available"
        '
        'btnprogrammerpath
        '
        Me.btnprogrammerpath.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnprogrammerpath.Location = New System.Drawing.Point(840, 63)
        Me.btnprogrammerpath.Name = "btnprogrammerpath"
        Me.btnprogrammerpath.Size = New System.Drawing.Size(117, 39)
        Me.btnprogrammerpath.TabIndex = 21
        Me.btnprogrammerpath.Text = "Load Content"
        Me.btnprogrammerpath.UseVisualStyleBackColor = True
        '
        'textboxprogrammer
        '
        Me.textboxprogrammer.BackColor = System.Drawing.SystemColors.Window
        Me.textboxprogrammer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.textboxprogrammer.Font = New System.Drawing.Font("Microsoft YaHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textboxprogrammer.Location = New System.Drawing.Point(222, 70)
        Me.textboxprogrammer.Multiline = True
        Me.textboxprogrammer.Name = "textboxprogrammer"
        Me.textboxprogrammer.ReadOnly = True
        Me.textboxprogrammer.Size = New System.Drawing.Size(580, 27)
        Me.textboxprogrammer.TabIndex = 20
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft PhagsPa", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(234, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 16)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Select Meta  Build"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.QCFT_LTE.My.Resources.Resources._5f20c745605a2
        Me.PictureBox1.Location = New System.Drawing.Point(10, 7)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(205, 229)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'infowindow
        '
        Me.infowindow.BackColor = System.Drawing.Color.White
        Me.infowindow.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.infowindow.Font = New System.Drawing.Font("Microsoft YaHei", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.infowindow.ForeColor = System.Drawing.Color.SeaGreen
        Me.infowindow.Location = New System.Drawing.Point(2, 287)
        Me.infowindow.Name = "infowindow"
        Me.infowindow.ReadOnly = True
        Me.infowindow.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedVertical
        Me.infowindow.ShowSelectionMargin = True
        Me.infowindow.Size = New System.Drawing.Size(979, 294)
        Me.infowindow.TabIndex = 8
        Me.infowindow.Text = ""
        '
        'checkBoxauto
        '
        Me.checkBoxauto.AutoSize = True
        Me.checkBoxauto.Font = New System.Drawing.Font("Microsoft YaHei", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkBoxauto.Location = New System.Drawing.Point(8, 587)
        Me.checkBoxauto.Name = "checkBoxauto"
        Me.checkBoxauto.Size = New System.Drawing.Size(124, 23)
        Me.checkBoxauto.TabIndex = 13
        Me.checkBoxauto.Text = "Auto Download"
        Me.checkBoxauto.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnexit.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(899, 587)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(82, 27)
        Me.btnexit.TabIndex = 12
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(2, 253)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(979, 28)
        Me.ProgressBar1.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnexit
        Me.ClientSize = New System.Drawing.Size(986, 622)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.checkBoxauto)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.infowindow)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "QCFT LTE"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents infowindow As System.Windows.Forms.RichTextBox
    Friend WithEvents checkBoxauto As System.Windows.Forms.CheckBox
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents phonemodel As System.Windows.Forms.TextBox
    Friend WithEvents swmodel As System.Windows.Forms.TextBox
    Friend WithEvents checkpPhoneModel As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents spccode As System.Windows.Forms.TextBox
    Friend WithEvents download As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents checkBox_BackupQCN As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox_RandomSPC As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnprogrammerpath As System.Windows.Forms.Button
    Friend WithEvents textboxprogrammer As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
