﻿

Public Delegate Sub DelReadStdOutput(result As String)