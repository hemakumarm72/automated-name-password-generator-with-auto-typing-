﻿



Public Delegate Sub dDownloadProgress(total As Long, current As Long, breset As Boolean)
