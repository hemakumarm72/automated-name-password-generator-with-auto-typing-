﻿

Public Delegate Sub DelReadErrOutput(result As String)

